//
//  TDSAccountNotification.h
//  TapBootstrapSDK
//
//  Created by Bottle K on 2021/4/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const TAP_LOGIN_SUCCESS_NOTIFICATION;
extern NSString *const TAP_LOGIN_FAIL_NOTIFICATION;

@interface TDSAccountNotification : NSObject

@end

NS_ASSUME_NONNULL_END
